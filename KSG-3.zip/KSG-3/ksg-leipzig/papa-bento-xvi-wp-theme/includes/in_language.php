<?php
?>
 <!--Language bar for desktop breakpoints-->
        <div class="language-bar">
            <div class="grid-width">
                <select id="language">
                    <option value="Deutsche">Deutsche</option>
                    <option value="English">English</option>
                </select>
            </div>
        </div>
  <!--End of Language bar for desktop breakpoints-->