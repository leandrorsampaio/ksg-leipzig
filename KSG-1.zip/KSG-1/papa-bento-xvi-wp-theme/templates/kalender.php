 <!--Our next events section-->

 <section id="next_events_overview" class="full-width default_padding margin_header">
 	<div class="grid-width">
 		<h2><?php the_title();?></h2>
 		<h1 class="month_title">August 2018</h1>
 		<!--Row of cards, overflow on mobile-->
 		<div class="row row_margin">

 			<!--Event card-->
 			<div class="event_card" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 		</div>
 		<!--End of Row of cards, overflow on mobile-->

 	</div>
 </section>
 <!--End of Our next events section-->

 <!--Our next events section-->
 <section id="next_events_overview" class="full-width default_padding other_months">
 	<div class="grid-width">
 		<h1>September 2018</h1>
 		<!--Row of cards, overflow on mobile-->
 		<div class="row row_margin">

 			<!--Event card-->
 			<div class="event_card card_type1" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card card_type2" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card card_type3" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 		</div>
 		<!--End of Row of cards, overflow on mobile-->
 		<!--Row of cards, overflow on mobile-->

 	</div>
 </section>
 <!--End of Our next events section-->

 <!--Our next events section-->
 <section id="next_events_overview" class="full-width default_padding month_gray">
 	<div class="grid-width">
 		<h1>October 2018</h1>
 		<!--Row of cards, overflow on mobile-->
 		<div class="row row_margin">

 			<!--Event card-->
 			<div class="event_card" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card card_type4" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 			<!--Event card-->
 			<div class="event_card card_type2" onclick="location.href='events.html';">
 				<div class="subcontainer">
 					<p class="day">24<span class="month">July</span></p>
 					<p class="where">Friday - 9am<br>Hotel Catholic di Berlin</p>
 					<p class="event_name">Heilige Messe</p>
 					<p class="event_description">A brief description of the event. Anything you can inform to convince people to come.</p>
 				</div>
 			</div>
 			<!--End of Event card-->

 		</div>
            <!--End of Row of cards, overflow on mobile-->
  	</section>
    <!--End of Our next events section-->